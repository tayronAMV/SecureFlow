import { useEffect, useRef, useCallback } from 'react';

export function useWebSocket(
  url: string,
  onMessage: (msg: string) => void,
  maxRetries = 5
) {
  const socketRef = useRef<WebSocket | null>(null);
  const retriesRef = useRef(0);

  const connect = useCallback(() => {
    try {
      if (socketRef.current) {
        socketRef.current.close();
      }

      const ws = new WebSocket(url);
      socketRef.current = ws;

      ws.onmessage = (event) => {
        onMessage(event.data); // message is plain string
      };

      ws.onopen = () => {
        console.log('WebSocket connected to', url);
        retriesRef.current = 0;
      };

      ws.onerror = (err) => {
        console.error('WebSocket error:', err);
      };

      ws.onclose = () => {
        console.warn('WebSocket closed');
        if (retriesRef.current < maxRetries) {
          const timeout = Math.min(1000 * 2 ** retriesRef.current, 10000);
          retriesRef.current++;
          console.log(`Reconnecting in ${timeout}ms... (Attempt ${retriesRef.current})`);
          setTimeout(connect, timeout);
        }
      };
    } catch (err) {
      console.error('Failed to create WebSocket connection:', err);
    }
  }, [url, onMessage, maxRetries]);

  useEffect(() => {
    connect();
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [connect]);

  return {
    reconnect: () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
      retriesRef.current = 0;
      connect();
    }
  };
}
